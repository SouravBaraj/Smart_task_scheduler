package scheduler;

import javax.swing.table.AbstractTableModel;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TaskTableModel extends AbstractTableModel {
    private final String[] cols = {"Title", "Priority", "Deadline", "Completed"};
    private final List<Task> rows = new ArrayList<>();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public void setRows(List<Task> tasks) {
        rows.clear();
        rows.addAll(tasks);
        fireTableDataChanged();
    }

    public Task getTaskAt(int modelRow) {
        return rows.get(modelRow);
    }

    @Override public int getRowCount() { return rows.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int c) { return cols[c]; }

    @Override public Class<?> getColumnClass(int c) {
        switch (c) {
            case 0: return String.class;
            case 1: return Priority.class;
            case 2: return String.class;   // render formatted string for readability
            case 3: return Boolean.class;
            default: return Object.class;
        }
    }

    @Override public Object getValueAt(int r, int c) {
        Task t = rows.get(r);
        switch (c) {
            case 0: return t.getTitle();
            case 1: return t.getPriority();
            case 2: return t.getDeadline() == null ? "" : FMT.format(t.getDeadline());
            case 3: return t.isCompleted();
        }
        return null;
    }
}
