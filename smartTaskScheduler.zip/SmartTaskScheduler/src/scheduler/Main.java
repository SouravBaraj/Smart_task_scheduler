package scheduler;

import javax.swing.*;
import javax.swing.RowFilter;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Comparator;
import javax.swing.SwingUtilities;

public class Main {

    private final TaskManager manager = new TaskManager();
    private final ReminderService reminders = new ReminderService();

    private JFrame frame;
    private JTable table;
    private TaskTableModel model;
    private TableRowSorter<TaskTableModel> sorter;

    // Inputs
    private JTextField titleField;
    private JComboBox<Priority> priorityBox;
    private JSpinner deadlineSpinner; // Date + time
    private JCheckBox todayOnly;
    private JCheckBox hideCompleted;
    private JComboBox<Object> priorityFilterBox;

    // Selection
    private Task selected;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().start());
    }

    private void start() {
        loadOnStart();
        buildUI();
        refreshTable();
    }

    private void buildUI() {
        frame = new JFrame("Smart Task Scheduler (Priority Queue)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Top form
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.gridy = 0;

        titleField = new JTextField();
        priorityBox = new JComboBox<>(Priority.values());

        deadlineSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(deadlineSpinner, "yyyy-MM-dd HH:mm");
        deadlineSpinner.setEditor(editor);

        addLabeled(form, gc, "Title:", titleField);
        addLabeled(form, gc, "Priority:", priorityBox);
        addLabeled(form, gc, "Deadline:", deadlineSpinner);

        JButton addBtn = new JButton("Add");
        addBtn.addActionListener(this::onAdd);
        JButton updateBtn = new JButton("Update");
        updateBtn.addActionListener(this::onUpdate);
        JButton deleteBtn = new JButton("Delete");
        deleteBtn.addActionListener(this::onDelete);
        JButton completeBtn = new JButton("Mark Complete");
        completeBtn.addActionListener(this::onMarkComplete);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.add(addBtn); btns.add(updateBtn); btns.add(deleteBtn); btns.add(completeBtn);

        // Filters
        todayOnly = new JCheckBox("Today's tasks only");
        hideCompleted = new JCheckBox("Hide completed");
        priorityFilterBox = new JComboBox<>(new Object[]{"All", Priority.LOW, Priority.MEDIUM, Priority.HIGH, Priority.CRITICAL});

        for (JCheckBox cb : new JCheckBox[]{todayOnly, hideCompleted}) {
            cb.addActionListener(e -> applyFilters());
        }
        priorityFilterBox.addActionListener(e -> applyFilters());

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        filters.add(new JLabel("Filter:"));
        filters.add(priorityFilterBox);
        filters.add(todayOnly);
        filters.add(hideCompleted);

        JPanel north = new JPanel(new BorderLayout());
        north.add(form, BorderLayout.CENTER);
        north.add(btns, BorderLayout.SOUTH);

        // Table
        model = new TaskTableModel();
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(this::onSelectRow);

        sorter = new TableRowSorter<>(model);
        sorter.setComparator(1, Comparator.comparingInt(p -> ((Priority)p).rank()).reversed());
        sorter.setComparator(2, Comparator.naturalOrder());
        table.setRowSorter(sorter);
        applyFilters();

        JScrollPane scroll = new JScrollPane(table);

        // Save / Load
        JButton saveBtn = new JButton("Save");
        saveBtn.addActionListener(e -> saveNow());
        JButton loadBtn = new JButton("Load");
        loadBtn.addActionListener(e -> { loadNow(); refreshTable(); });
        JButton clearBtn = new JButton("Clear All");
        clearBtn.addActionListener(e -> { manager.clear(); reminders.cancelAll(); refreshTable(); });

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(saveBtn); south.add(loadBtn); south.add(clearBtn);

        frame.getContentPane().add(north, BorderLayout.NORTH);
        frame.getContentPane().add(scroll, BorderLayout.CENTER);
        frame.getContentPane().add(filters, BorderLayout.WEST);
        frame.getContentPane().add(south, BorderLayout.SOUTH);

        frame.setSize(840, 520);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void addLabeled(JPanel panel, GridBagConstraints gc, String label, JComponent comp) {
        gc.gridx = 0; gc.weightx = 0; panel.add(new JLabel(label), gc);
        gc.gridx = 1; gc.weightx = 1; panel.add(comp, gc);
        gc.gridy++;
    }

    private void onAdd(ActionEvent e) {
        Task t = new Task(
                titleField.getText().trim(),
                (Priority) priorityBox.getSelectedItem(),
                spinnerToLDT(deadlineSpinner)
        );
        manager.add(t);
        reminders.reschedule(t);
        clearForm();
        refreshTable();
    }

    private void onUpdate(ActionEvent e) {
        if (selected == null) return;
        selected.setTitle(titleField.getText().trim());
        selected.setPriority((Priority) priorityBox.getSelectedItem());
        selected.setDeadline(spinnerToLDT(deadlineSpinner));
        reminders.reschedule(selected);
        refreshTable();
    }

    private void onDelete(ActionEvent e) {
        if (selected == null) return;
        reminders.cancel(selected.getId());
        manager.remove(selected);
        selected = null;
        clearForm();
        refreshTable();
    }

    private void onMarkComplete(ActionEvent e) {
        if (selected == null) return;
        manager.markCompleted(selected, true);
        reminders.cancel(selected.getId());
        refreshTable();
    }

    private void onSelectRow(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) { selected = null; return; }
        int modelRow = table.convertRowIndexToModel(viewRow);
        selected = model.getTaskAt(modelRow);

        titleField.setText(selected.getTitle());
        priorityBox.setSelectedItem(selected.getPriority());
        if (selected.getDeadline() != null) {
            deadlineSpinner.setValue(java.util.Date
                    .from(selected.getDeadline().atZone(ZoneId.systemDefault()).toInstant()));
        }
    }

    private void applyFilters() {
        sorter.setRowFilter(new RowFilter<>() {
            @Override
            public boolean include(RowFilter.Entry<? extends TaskTableModel, ? extends Integer> entry) {
                int modelRow = entry.getIdentifier();
                Task t = model.getTaskAt(modelRow);

                Object pf = priorityFilterBox.getSelectedItem();
                if (pf instanceof Priority && t.getPriority() != pf) return false;

                if (todayOnly.isSelected() && !TaskManager.isToday(t.getDeadline())) return false;

                if (hideCompleted.isSelected() && t.isCompleted()) return false;

                return true;
            }
        });
    }

    private void refreshTable() {
        model.setRows(manager.getAllSorted());
        applyFilters();
    }

    private void clearForm() {
        titleField.setText("");
        priorityBox.setSelectedItem(Priority.MEDIUM);
        deadlineSpinner.setValue(java.util.Date.from(
                LocalDateTime.now().plusHours(1)
                        .atZone(ZoneId.systemDefault()).toInstant()));
    }

    private static LocalDateTime spinnerToLDT(JSpinner spinner) {
        java.util.Date d = (java.util.Date) spinner.getValue();
        return d == null ? null :
                LocalDateTime.ofInstant(d.toInstant(), ZoneId.systemDefault());
    }

    private void saveNow() {
        Path file = TaskManager.defaultFile();
        try {
            manager.save(file);
            JOptionPane.showMessageDialog(frame, "Saved to " + file.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Save failed: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadNow() {
        Path file = TaskManager.defaultFile();
        try {
            manager.load(file);
            reminders.cancelAll();
            for (Task t : manager.getAllSorted()) reminders.reschedule(t);
            JOptionPane.showMessageDialog(frame, "Loaded from " + file.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Load failed: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadOnStart() {
        try { manager.load(TaskManager.defaultFile()); }
        catch (Exception ignored) { }
    }
}
