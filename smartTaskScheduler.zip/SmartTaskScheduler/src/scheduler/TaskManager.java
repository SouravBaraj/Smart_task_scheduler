package scheduler;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class TaskManager implements Serializable {
    private static final long serialVersionUID = 1L;

    private final List<Task> tasks = new ArrayList<>();

    // Incomplete first, then higher priority, then earliest deadline, then older creation time
    private static final Comparator<Task> ORDER = Comparator
            .comparing(Task::isCompleted)                         // false before true
            .thenComparing((Task t) -> -t.getPriority().rank())   // higher rank first
            .thenComparing(Task::getDeadline,
                    Comparator.nullsLast(Comparator.naturalOrder())) // earlier first
            .thenComparing(Task::getCreatedAt);

    public List<Task> getAllSorted() {
        return tasks.stream().sorted(ORDER).collect(Collectors.toList());
    }

    public void add(Task t) { tasks.add(t); }

    public void remove(Task t) { tasks.remove(t); }

    public Optional<Task> findById(UUID id) {
        return tasks.stream().filter(x -> x.getId().equals(id)).findFirst();
    }

    public void markCompleted(Task t, boolean completed) {
        t.setCompleted(completed);
    }

    public void clear() { tasks.clear(); }

    // Simple binary file persistence (no external libraries)
    public void save(Path file) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(file))) {
            out.writeObject(tasks);
        }
    }

    @SuppressWarnings("unchecked")
    public void load(Path file) throws IOException, ClassNotFoundException {
        if (!Files.exists(file)) return;
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(file))) {
            tasks.clear();
            tasks.addAll((List<Task>) in.readObject());
        }
    }

    // Convenience for default location
    public static Path defaultFile() {
        return Path.of(System.getProperty("user.home"), "tasks.dat");
    }

    // Utility
    public static boolean isToday(LocalDateTime dt) {
        if (dt == null) return false;
        var today = java.time.LocalDate.now();
        return today.equals(dt.toLocalDate());
    }
}
