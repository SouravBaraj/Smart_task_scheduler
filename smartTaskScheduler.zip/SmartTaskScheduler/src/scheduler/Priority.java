package scheduler;

public enum Priority {
    LOW, MEDIUM, HIGH, CRITICAL;

    public int rank() {
        switch (this) {
            case CRITICAL: return 4;
            case HIGH:     return 3;
            case MEDIUM:   return 2;
            case LOW:      return 1;
            default:       return 0;
        }
    }

    @Override
    public String toString() {
        String s = name().toLowerCase();
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
