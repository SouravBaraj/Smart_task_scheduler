package scheduler;

import javax.swing.*;
import java.time.*;
import java.util.*;
import java.util.Timer;

public class ReminderService {
    private final Timer timer = new Timer(true);
    private final Map<UUID, TimerTask> scheduled = new HashMap<>();

    public void reschedule(Task task) {
        cancel(task.getId());
        if (task.isCompleted() || task.getDeadline() == null) return;

        long delayMs = millisUntil(task.getDeadline());
        if (delayMs < 1000) delayMs = 1000; // if overdue or very soon, nudge to ~1s

        TimerTask tt = new TimerTask() {
            @Override public void run() {
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(null,
                                "Deadline now: " + task.getTitle(),
                                "Task Reminder",
                                JOptionPane.INFORMATION_MESSAGE));
            }
        };
        timer.schedule(tt, delayMs);
        scheduled.put(task.getId(), tt);
    }

    public void cancel(UUID id) {
        TimerTask old = scheduled.remove(id);
        if (old != null) old.cancel();
    }

    public void cancelAll() {
        for (TimerTask t : scheduled.values()) t.cancel();
        scheduled.clear();
    }

    private static long millisUntil(LocalDateTime when) {
        Instant now = Instant.now();
        Instant target = when.atZone(ZoneId.systemDefault()).toInstant();
        return Math.max(0L, target.toEpochMilli() - now.toEpochMilli());
    }
}
