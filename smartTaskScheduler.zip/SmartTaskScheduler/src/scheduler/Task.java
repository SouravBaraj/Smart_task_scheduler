package scheduler;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

public class Task implements Serializable {
    private static final long serialVersionUID = 1L;

    private final UUID id;
    private String title;
    private Priority priority;
    private LocalDateTime deadline;
    private boolean completed;
    private final LocalDateTime createdAt;

    public Task(String title, Priority priority, LocalDateTime deadline) {
        this.id = UUID.randomUUID();
        this.title = title;
        this.priority = priority == null ? Priority.MEDIUM : priority;
        this.deadline = deadline;
        this.completed = false;
        this.createdAt = LocalDateTime.now();
    }

    public UUID getId() { return id; }
    public String getTitle() { return title; }
    public Priority getPriority() { return priority; }
    public LocalDateTime getDeadline() { return deadline; }
    public boolean isCompleted() { return completed; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setTitle(String title) { this.title = title; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public void setDeadline(LocalDateTime deadline) { this.deadline = deadline; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Task)) return false;
        return Objects.equals(id, ((Task) o).id);
    }

    @Override
    public int hashCode() { return Objects.hash(id); }
}
