module SmartTaskScheduler {
    requires java.desktop;   // ✅ this enables Swing, AWT, etc.
}
